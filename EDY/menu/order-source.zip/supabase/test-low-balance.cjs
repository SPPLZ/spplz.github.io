const base='https://uorfvttjohseocwnjgqz.supabase.co/functions/v1/edy-account';
const key='sb_publishable_8WzLX4Ft4zWYypf2x2wNSg_Xt5zD2G6';
const username='alert_'+Date.now();
async function call(body,token){const r=await fetch(base,{method:'POST',headers:{apikey:key,'content-type':'application/json',...(token?{authorization:'Bearer '+token}:{})},body:JSON.stringify(body)});return {status:r.status,data:await r.json()}}
function assert(v,message){if(!v)throw Error(message)}
function order(){return 'DL_'+crypto.randomUUID().replaceAll('-','')}
(async()=>{
 const user=await call({action:'signup',id:username,password:'test1234!'});assert(user.status===200,'가입 실패 '+JSON.stringify(user.data));
 const admin=await call({action:'login',id:'admin',password:'qwer1234!'});assert(admin.status===200,'관리자 로그인 실패');
 const u=user.data.access_token,a=admin.data.access_token;
 const initial=await call({action:'me'},u);assert(initial.data.balance===40000,'초기 잔액 오류: '+JSON.stringify(initial.data));
 const denied=await call({action:'alerts'},u);assert(denied.status===403,'일반 회원 알림 접근 허용됨');
 const debit=await call({action:'debit',order:order(),amount:30000},u);assert(debit.status===200&&debit.data.balance===10000,'기준 금액 차감 실패');
 let alerts=await call({action:'alerts'},a);assert(alerts.status===200,'관리자 알림 조회 실패: '+JSON.stringify(alerts.data));
 let own=alerts.data.alerts.filter(x=>x.edy_profiles?.username===username);assert(own.length===1&&own[0].balance===10000,'알림 기록 오류: '+JSON.stringify(own));
 await call({action:'debit',order:order(),amount:1},u);
 alerts=await call({action:'alerts'},a);own=alerts.data.alerts.filter(x=>x.edy_profiles?.username===username);assert(own.length===1,'중복 알림 발생');
 const credit=await call({action:'credit',target:username,amount:10000},a);assert(credit.status===200,'재충전 실패');
 await call({action:'debit',order:order(),amount:9999},u);
 alerts=await call({action:'alerts'},a);own=alerts.data.alerts.filter(x=>x.edy_profiles?.username===username);assert(own.length===2,'재진입 알림 누락');
 console.log(JSON.stringify({username,initialBalance:40000,alertAt10000:true,nonAdminDenied:true,noDuplicates:true,repeatAfterRecharge:true}));
})().catch(e=>{console.error(e.message);process.exitCode=1});
