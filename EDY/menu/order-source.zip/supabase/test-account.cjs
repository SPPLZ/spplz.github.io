const base='https://uorfvttjohseocwnjgqz.supabase.co/functions/v1/edy-account';
const key='sb_publishable_8WzLX4Ft4zWYypf2x2wNSg_Xt5zD2G6';
const username='test_'+Date.now();
async function call(body,token){const r=await fetch(base,{method:'POST',headers:{apikey:key,'content-type':'application/json',...(token?{authorization:'Bearer '+token}:{})},body:JSON.stringify(body)});const data=await r.json();return {status:r.status,data}}
function assert(condition,message){if(!condition)throw Error(message)}
(async()=>{
 const user=await call({action:'signup',id:username,password:'test1234!'});assert(user.status===200&&user.data.access_token,'signup failed: '+JSON.stringify(user.data));
 const admin=await call({action:'login',id:'admin',password:'qwer1234!'});assert(admin.status===200&&admin.data.access_token,'admin login failed');
 const a=admin.data.access_token,u=user.data.access_token;
 const deny=await call({action:'credit',target:username,amount:2500},u);assert(deny.status===403,'non-admin credit was not rejected');
 const before=await call({action:'me'},u);assert(before.status===200&&before.data.balance===0,'initial balance incorrect');
 const credit=await call({action:'credit',target:username,amount:2500},a);assert(credit.status===200&&credit.data.balance===2500,'admin credit failed: '+JSON.stringify(credit.data));
 const after=await call({action:'me'},u);assert(after.data.balance===2500,'credit did not persist');
 const order='DL_'+crypto.randomUUID().replaceAll('-','');
 const paid=await call({action:'debit',order,amount:700},u);assert(paid.status===200&&paid.data.balance===1800,'debit failed');
 const retry=await call({action:'debit',order,amount:700},u);assert(retry.status===200&&retry.data.balance===1800,'idempotent retry failed');
 const no=await call({action:'debit',order:'DL_'+crypto.randomUUID().replaceAll('-',''),amount:99999},u);assert(no.status===400,'overdraft not rejected');
 console.log(JSON.stringify({username,signup:true,adminLogin:true,nonAdminDenied:true,credit:true,debit:true,retry:true,overdraftDenied:true}));
})().catch(e=>{console.error(e.message);process.exitCode=1});
