-- Applied to the demo database as migration edy_daily_pickup_numbers.
create table public.edy_pickup_daily_counters (service_date date primary key, last_number bigint not null check (last_number > 0));
create table public.edy_pickup_numbers (order_id text primary key, user_id uuid not null, service_date date not null, pickup_number bigint not null check (pickup_number > 0), created_at timestamptz not null default now(), unique(service_date, pickup_number));
alter table public.edy_pickup_daily_counters enable row level security;
alter table public.edy_pickup_numbers enable row level security;
revoke all on public.edy_pickup_daily_counters, public.edy_pickup_numbers from public, anon, authenticated;
create function public.edy_allocate_pickup_number(p_order text) returns text language plpgsql security definer set search_path = '' as $$
declare v_user uuid := auth.uid(); v_date date := (pg_catalog.clock_timestamp() at time zone 'Asia/Seoul')::date; v_number bigint; v_owner uuid;
begin
  if v_user is null then raise exception '로그인이 필요합니다' using errcode='42501'; end if;
  if p_order is null or p_order !~ '^DL_[a-f0-9]{32}$' then raise exception '주문 번호를 확인해주세요'; end if;
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(p_order, 0));
  select user_id, pickup_number into v_owner, v_number from public.edy_pickup_numbers where order_id=p_order;
  if found then
    if v_owner <> v_user then raise exception '주문을 확인할 수 없습니다' using errcode='42501'; end if;
  else
    insert into public.edy_pickup_daily_counters as counters(service_date,last_number) values(v_date,1) on conflict(service_date) do update set last_number=counters.last_number+1 returning last_number into v_number;
    insert into public.edy_pickup_numbers(order_id,user_id,service_date,pickup_number) values(p_order,v_user,v_date,v_number);
  end if;
  return case when v_number < 1000 then pg_catalog.lpad(v_number::text,3,'0') else v_number::text end;
end; $$;
revoke all on function public.edy_allocate_pickup_number(text) from public, anon;
grant execute on function public.edy_allocate_pickup_number(text) to authenticated;
