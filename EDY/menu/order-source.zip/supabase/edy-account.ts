import { createClient } from 'npm:@supabase/supabase-js@2.95.0';

const url = Deno.env.get('SUPABASE_URL')!;
const service = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const anon = Deno.env.get('SUPABASE_ANON_KEY')!;
const db = createClient(url, service, {auth:{persistSession:false,autoRefreshToken:false}});
const cors = {'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info','Access-Control-Allow-Methods':'POST, OPTIONS','Content-Type':'application/json'};
const reply = (value: unknown, status=200) => new Response(JSON.stringify(value), {status,headers:cors});
const emailFor = (id:string) => id+'@edy-demo.invalid';

async function createAccount(username:string, password:string) {
  const {data,error} = await db.auth.admin.createUser({email:emailFor(username),password,email_confirm:true});
  if (error || !data.user) throw new Error('계정을 만들 수 없습니다. 아이디 또는 비밀번호를 확인해주세요.');
  const userId=data.user.id;
  const profile=await db.from('edy_profiles').insert({user_id:userId,username});
  const wallet=profile.error ? profile : await db.from('edy_wallets').insert({user_id:userId});
  if (wallet.error) { await db.auth.admin.deleteUser(userId); throw new Error('계정을 저장하지 못했습니다.'); }
}

Deno.serve(async req=>{
 if(req.method==='OPTIONS') return new Response('ok',{headers:cors});
 if(req.method!=='POST') return reply({error:'지원하지 않는 요청입니다.'},405);
 try {
  const body=await req.json();
  const id=String(body.id||'').trim().toLowerCase();
  const password=String(body.password||'');
  if(body.action==='signup'||body.action==='login') {
   if(!/^[a-z0-9_]{3,30}$/.test(id)||password.length<8||password.length>72) throw new Error('아이디는 영문 소문자·숫자·밑줄 3~30자, 비밀번호는 8~72자로 입력해주세요.');
   if(body.action==='signup') {
    if(id==='admin') throw new Error('사용할 수 없는 아이디입니다.');
    await createAccount(id,password);
   }
   // The assignment explicitly defines this publicly known demonstration account.
   if(body.action==='login' && id==='admin' && password==='qwer1234!') {
    const {data:existing,error}=await db.from('edy_profiles').select('user_id').eq('username','admin').maybeSingle();
    if(error) throw error;
    if(!existing) { try { await createAccount('admin',password); } catch { /* concurrent initialization */ } }
   }
   const client=createClient(url,anon,{auth:{persistSession:false,autoRefreshToken:false}});
   const {data,error}=await client.auth.signInWithPassword({email:emailFor(id),password});
   if(error||!data.session) throw new Error('아이디 또는 비밀번호를 확인해주세요.');
   return reply({access_token:data.session.access_token,refresh_token:data.session.refresh_token,expires_at:data.session.expires_at});
  }
  const token=(req.headers.get('Authorization')||'').replace(/^Bearer\s+/i,'');
  const {data:{user},error:authError}=await db.auth.getUser(token);
  if(authError||!user) return reply({error:'다시 로그인해주세요.'},401);
  const {data:profile,error:profileError}=await db.from('edy_profiles').select('username').eq('user_id',user.id).single();
  if(profileError||!profile) throw new Error('계정을 찾을 수 없습니다.');
  if(body.action==='me') {
   const {data:wallet,error}=await db.from('edy_wallets').select('balance').eq('user_id',user.id).single();
   if(error) throw error;
   return reply({id:profile.username,isAdmin:profile.username==='admin',balance:wallet.balance});
  }
  if(body.action==='alerts') {
   if(profile.username!=='admin') return reply({error:'관리자 권한이 필요합니다.'},403);
   const {data,error}=await db.from('edy_low_balance_alerts').select('id,balance,created_at,edy_profiles(username)').order('created_at',{ascending:false}).limit(50);
   if(error) throw error;
   return reply({alerts:data});
  }
  if(body.action==='users') {
   if(profile.username!=='admin') return reply({error:'관리자 권한이 필요합니다.'},403);
   const users:{username:string,balance:number|null}[]=[];
   for(let offset=0;;offset+=1000) {
    const {data,error}=await db.from('edy_profiles').select('username,edy_wallets(balance)').order('username').range(offset,offset+999);
    if(error) throw error;
    users.push(...data.map(row=>({username:row.username,balance:row.edy_wallets?.balance ?? null})));
    if(data.length<1000) break;
   }
   return reply({users});
  }
  if(body.action==='credit') {
   if(profile.username!=='admin') return reply({error:'관리자 권한이 필요합니다.'},403);
   const target=String(body.target||'').trim().toLowerCase(), amount=Number(body.amount);
   if(!/^[a-z0-9_]{3,30}$/.test(target)||!Number.isSafeInteger(amount)||amount<1||amount>10000000) throw new Error('계정 또는 금액을 확인해주세요.');
   const {data,error}=await db.rpc('edy_admin_credit',{p_actor:user.id,p_target:target,p_amount:amount});
   if(error) throw new Error(error.message);
   return reply({balance:data});
  }
  if(body.action==='debit') {
   const order=String(body.order||''), amount=Number(body.amount);
   if(!/^DL_[a-f0-9]{32}$/.test(order)||!Number.isSafeInteger(amount)||amount<0||amount>1000000) throw new Error('주문 정보를 확인해주세요.');
   const {data,error}=await db.rpc('edy_debit',{p_user:user.id,p_order:order,p_amount:amount});
   if(error) throw new Error(error.message);
   return reply({balance:data});
  }
  return reply({error:'지원하지 않는 요청입니다.'},400);
 } catch(e) { return reply({error:e instanceof Error?e.message:'처리하지 못했습니다.'},400); }
});
