import {defineConfig} from 'vite';import react from '@vitejs/plugin-react';import path from 'node:path';
export default defineConfig({base:'/EDY/menu/',plugins:[react()],resolve:{alias:{'@':path.resolve('.')}},build:{outDir:'dist'}});
