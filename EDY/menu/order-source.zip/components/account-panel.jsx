import React, {useEffect,useState} from 'react';
import {getLowBalanceAlerts,getUserList} from '../lib/account-client';

// The parent supplies authenticated server operations; this component never
// treats a client-side flag as authorization to change another user's balance.
export default function AccountPanel({account, onLogin, onRegister, onLogout, onCredit}) {
  const [id, setId] = useState('');
  const [password, setPassword] = useState('');
  const [registering, setRegistering] = useState(false);
  const [target, setTarget] = useState('');
  const [amount, setAmount] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [alerts,setAlerts] = useState([]);
  const [alertError,setAlertError] = useState('');
  const [users,setUsers] = useState([]);
  const [usersError,setUsersError] = useState('');
  const [usersLoading,setUsersLoading] = useState(false);
  async function loadUsers(){setUsersLoading(true);setUsersError('');try{const result=await getUserList();setUsers(result.users||[])}catch{setUsersError('회원 목록을 불러오지 못했습니다. 다시 시도해주세요.')}finally{setUsersLoading(false)}}
  useEffect(()=>{if(account?.isAdmin){void loadUsers()}else{setUsers([]);setUsersError('')}},[account?.id,account?.isAdmin]);
  useEffect(()=>{
    if(!account?.isAdmin){setAlerts([]);return}
    let active=true;
    const load=()=>getLowBalanceAlerts().then(result=>{if(active){setAlerts(result.alerts||[]);setAlertError('')}}).catch(()=>{if(active)setAlertError('알림을 불러오지 못했습니다.')});
    load();const timer=setInterval(load,15000);
    return()=>{active=false;clearInterval(timer)};
  },[account?.id,account?.isAdmin]);
  async function run(action) {
    setBusy(true); setMessage('');
    try { await action(); setPassword(''); setMessage('처리되었습니다.'); }
    catch (error) { setMessage(error?.message || '처리하지 못했습니다. 다시 시도해주세요.'); }
    finally { setBusy(false); }
  }
  const input = 'w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm';
  const button = 'w-full rounded-xl bg-sky-500 px-4 py-3 text-sm font-bold text-white disabled:opacity-50';
  return <section className="m-4 space-y-4 rounded-2xl border border-sky-100 bg-white p-5">
    <h2 className="text-lg font-bold">계정 관리</h2>
    {!account ? <form className="space-y-3" onSubmit={event => { event.preventDefault(); run(() => (registering ? onRegister : onLogin)(id.trim(), password)); }}>
      <label className="block text-xs font-medium">아이디<input className={input} autoComplete="username" required value={id} onChange={event => setId(event.target.value)} /></label>
      <label className="block text-xs font-medium">비밀번호<input className={input} type="password" autoComplete={registering ? 'new-password' : 'current-password'} required value={password} onChange={event => setPassword(event.target.value)} /></label>
      <button className={button} disabled={busy}>{registering ? '회원가입' : '로그인'}</button>
      <button type="button" className="text-sm text-sky-700 underline" onClick={() => { setRegistering(!registering); setMessage(''); }}>{registering ? '로그인으로 돌아가기' : '새 계정 만들기'}</button>
    </form> : <div className="space-y-4">
      <div className="flex items-center justify-between"><p className="text-sm"><strong>{account.id}</strong> 님</p><button className="text-sm text-sky-700 underline" disabled={busy} onClick={() => run(onLogout)}>로그아웃</button></div>
      {account.isAdmin && <><div className="space-y-2 border-t border-slate-100 pt-4"><div className="flex items-center justify-between"><h3 className="font-bold">가입된 회원 ({users.length}명)</h3><button type="button" onClick={loadUsers} disabled={usersLoading} className="text-xs text-sky-700 underline disabled:opacity-50">{usersLoading?'불러오는 중…':'새로고침'}</button></div><p className="text-xs text-slate-500">아이디를 누르면 충전할 계정에 입력됩니다.</p>{usersError&&<p role="alert" className="text-xs text-red-600">{usersError}</p>}<ul className="max-h-48 overflow-y-auto space-y-1">{users.map(user=><li key={user.username}><button type="button" onClick={()=>setTarget(user.username)} className="w-full rounded-xl bg-sky-50 px-3 py-2 text-left text-sm text-slate-800 hover:bg-sky-100">{user.username} ({user.balance == null ? '잔액 확인 불가' : Number(user.balance).toLocaleString('ko-KR') + '원'})</button></li>)}</ul></div><div className="space-y-2 border-t border-slate-100 pt-4"><h3 className="font-bold">잔액 부족 알림</h3><p className="text-xs text-slate-500">잔액이 10,000원 이하로 내려가면 표시됩니다.</p>{alertError && <p role="alert" className="text-xs text-red-600">{alertError}</p>}{alerts.length===0&&!alertError&&<p className="text-xs text-slate-500">새로운 알림이 없습니다.</p>}<ul className="space-y-2">{alerts.map(item=><li key={item.id} className="rounded-xl bg-sky-50 p-3 text-sm"><strong>{item.edy_profiles?.username || '회원'}</strong>님의 자금이 부족합니다. <span className="font-bold">{Number(item.balance).toLocaleString()}원</span><div className="mt-1 text-xs text-slate-500">{new Date(item.created_at).toLocaleString('ko-KR')}</div></li>)}</ul></div><form className="space-y-3 border-t border-slate-100 pt-4" onSubmit={event => { event.preventDefault(); const value=Number(amount); if (!Number.isSafeInteger(value) || value <= 0) { setMessage('충전 금액을 올바르게 입력해주세요.'); return; } run(async () => { await onCredit(target.trim(), value); setAmount(''); await loadUsers(); }); }}>
        <h3 className="font-bold">관리자 테스트 잔액 충전</h3>
        <label className="block text-xs font-medium">충전할 계정<input className={input} required value={target} onChange={event => setTarget(event.target.value)} placeholder="아이디" /></label>
        <label className="block text-xs font-medium">충전 금액<input className={input} type="number" inputMode="numeric" min="1" step="1" required value={amount} onChange={event => setAmount(event.target.value)} placeholder="금액 (원)" /></label>
        <button className={button} disabled={busy}>테스트 잔액 충전</button>
      </form></>}
    </div>}
    {message && <p role="status" className="text-sm text-slate-600">{message}</p>}
  </section>;
}
