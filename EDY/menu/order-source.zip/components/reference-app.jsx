'use client';
import {useMember,api} from './member-provider';
import AccountPanel from './account-panel';

import {products,defaults,unitPrice} from '@/lib/catalog';
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Home, 
  Coffee, 
  Ticket, 
  CreditCard, 
  User, 
  MapPin, 
  Search, 
  ShoppingBag, 
  Plus, 
  Minus, 
  ChevronRight, 
  Check, 
  Clock, 
  QrCode, 
  Bell, 
  Sparkles, 
  ArrowLeft,
  X,
  RefreshCw,
  Gift,
  Zap,
  Info,
  Smartphone,
  Monitor,
  PlusCircle,
  GraduationCap
} from 'lucide-react';

// ==========================================
// CONSTANTS & INITIAL DATA - EODIYA COFFEE
// ==========================================
const STORE_NAME = '대림대학교점';
const STORE_ADDRESS = '경기 안양시 동안구 임곡로 29 (대림대학교 캠퍼스)';

const CATEGORIES = ['추천메뉴', '커피', '라떼/베버리지', '블렌딩티/에이드', '플랫치노/스무디', '디저트/베이커리', 'MD'];

const MENU_ITEMS = products.map(p=>({...p,nameEn:p.en,isHotIce:p.drink&&!p.iced,badge:p.tag}));

const INITIAL_COUPONS = [
  { id: 'c1', name: '[대림대 신입생/재학생 환영] 1,000원 할인 쿠폰', discount: 1000, type: 'AMOUNT', minPrice: 2500, expiry: '2026.12.31', code: 'EODIYA-WELCOME-2026' },
  { id: 'c2', name: '[스탬프 완성] 무료 아메리카노 (대림대 전용)', discount: 2500, type: 'ITEM', itemMatch: '딥 에스프레소 아메리카노', expiry: '2026.11.30', code: 'EODIYA-FREE-AME' }
];

// Web Audio API Sound Chime Helper
const playAudioChime = () => {
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    const ctx = new AudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.type = 'sine';
    osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
    osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.3); // A5
    
    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
    
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    osc.start();
    osc.stop(ctx.currentTime + 0.5);
    osc.onended=()=>ctx.close();
  } catch (e) {
    // Audio permission restrictions
  }
};

// ==========================================
// MAIN COMPONENT
// ==========================================
export default function App() {
  const ctx=useMember();
  const [dismissedLogin,setDismissedLogin]=useState(false);
  const [viewMode,setViewMode]=useState('mobile');
  useEffect(()=>{const media=window.matchMedia('(min-width: 900px)');const apply=()=>setViewMode(media.matches?'desktop':'mobile');apply();media.addEventListener('change',apply);return()=>media.removeEventListener('change',apply)},[]);
  const [activeTab,setActiveTab]=useState('order');
  const userTier='BLUE',stamps=ctx.member?.stamps||0,daelimPayBalance=ctx.member?.balance||0;
  const coupons=(ctx.member?.coupons||[]).filter(c=>!c.used&&c.expires>Date.now()).map(c=>({...c,discount:c.amount,type:c.kind==='m4'?'ITEM':'AMOUNT',expiry:new Date(c.expires).toLocaleDateString('ko-KR'),code:c.id.slice(0,8).toUpperCase()}));
  const cart=ctx.cart.map(i=>{const p=MENU_ITEMS.find(p=>p.id===i.productId);return {...p,cartId:i.id,quantity:i.quantity,temperature:i.options.temperature,cupType:i.options.cup,size:i.options.size==='EX'?'EXTRA':'REGULAR',extraShots:i.options.shots,vanillaSyrup:i.options.syrupShots,iceAmount:i.options.ice,unitPrice:unitPrice(i),totalPrice:unitPrice(i)*i.quantity}});
  const [customizingItem,setCustomizingItem]=useState(null),[appliedCoupon,setAppliedCoupon]=useState(null),[payMethod,setPayMethod]=useState('EODIYA_PAY');
  const [activeOrder,setActiveOrder]=useState(null),[orderStep,setOrderStep]=useState(1),[isProcessing,setIsProcessing]=useState(false);
  const [showTopUpModal,setShowTopUpModal]=useState(false),[showBarcodeModal,setShowBarcodeModal]=useState(null),[toastMessage,setToastMessage]=useState(null),[searchQuery,setSearchQuery]=useState(''),[selectedCategory,setSelectedCategory]=useState('추천메뉴');
  const [address,setAddress]=useState(''),[pending,setPending]=useState(null),[paymentError,setPaymentError]=useState('');
  const triggerToast=msg=>setToastMessage(msg);
  useEffect(()=>{if(!toastMessage)return;const t=setTimeout(()=>setToastMessage(null),3500);return()=>clearTimeout(t)},[toastMessage]);
  useEffect(()=>{const h=location.hash.slice(1);if(['home','order','coupon','pay','my','checkout'].includes(h))setActiveTab(h)},[]);
  const activeId=ctx.member?.orders.find(o=>o.status==='paid'&&!o.pickedAt)?.id;
  function adaptOrder(o){setOrderStep(({accepted:1,preparing:2,ready:3,completed:4})[o.stage]||1);setActiveOrder({...o,orderId:o.number,earnedStamps:o.stamps,timestamp:new Date(o.created).toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'})})}
  useEffect(()=>{if(!activeId)return;let live=true;const update=()=>api('/api/orders/'+activeId).then(r=>{if(live)adaptOrder(r.order)}).catch(e=>{if(live)triggerToast(e.message)});update();const timer=setInterval(update,2000);return()=>{live=false;clearInterval(timer)}},[activeId]);
  useEffect(()=>{const modal=document.querySelector('[role="dialog"]');if(!modal)return;const previous=document.activeElement;const controls=()=>[...modal.querySelectorAll('button,input,select,[tabindex="0"]')].filter(e=>!e.disabled);controls()[0]?.focus();const key=e=>{if(e.key==='Escape'){setCustomizingItem(null);setShowTopUpModal(false);setShowBarcodeModal(null)}if(e.key==='Tab'){const c=controls(),first=c[0],last=c[c.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus()}}};document.addEventListener('keydown',key);return()=>{document.removeEventListener('keydown',key);previous?.focus?.()}},[customizingItem,showTopUpModal,showBarcodeModal]);
  const cartSubtotal=cart.reduce((s,i)=>s+i.unitPrice*i.quantity,0);
  const validCoupon=appliedCoupon&&coupons.find(c=>c.id===appliedCoupon.id&&!c.reserved&&(c.kind!=='m4'||ctx.cart.some(i=>i.productId==='m4')));
  const couponDiscount=validCoupon?Math.min(cartSubtotal,validCoupon.discount):0;
  const cartTotal=cartSubtotal-couponDiscount+(ctx.mode==='delivery'&&cart.length?2500:0);
  useEffect(()=>{setPaymentError('')},[cartTotal]);
  function handleAddToCart(i){ctx.setCart([...ctx.cart,{id:crypto.randomUUID(),productId:i.id,quantity:i.quantity,options:{...defaults,temperature:i.temperature,cup:i.cupType,size:i.size==='EXTRA'?'EX':'R',shots:i.extraShots,syrupShots:i.vanillaSyrup,syrup:i.sweetness||'기본',ice:i.iceAmount}}]);setCustomizingItem(null);triggerToast(i.name+'을 담았어요.')}
  function handleUpdateQty(id,delta){ctx.setCart(ctx.cart.map(i=>i.id===id?{...i,quantity:Math.min(20,i.quantity+delta)}:i).filter(i=>i.quantity>0))}
  async function handleCheckout(){if(isProcessing||!ctx.member)return;setIsProcessing(true);setPaymentError('');try{if(!pending&&appliedCoupon&&!validCoupon)throw new Error('쿠폰 조건을 확인하거나 쿠폰을 해제해주세요.');const order=pending||(await api('/api/orders',{items:ctx.cart,couponId:validCoupon?.id||'',storeId:'campus',mode:ctx.mode,address,paymentMethod:({EODIYA_PAY:'WALLET',TOSS:'TOSSPAY',KAKAO:'KAKAOPAY',NAVER:'NAVERPAY',APPLE:'APPLEPAY',CARD:'CARD'})[payMethod]})).order;setPending(order);await api('/api/payment/complete',{orderId:order.id,amount:order.amount});const confirmed=(await api('/api/orders/'+order.id)).order;ctx.setCart([]);setPending(null);setAppliedCoupon(null);await ctx.refresh();adaptOrder(confirmed);setActiveTab('status')}catch(e){setPaymentError(e.message);triggerToast(e.message)}finally{setIsProcessing(false)}}
  async function cancelPending(){try{await api('/api/orders/'+pending.id,{action:'cancel'});setPending(null);setPaymentError('');await ctx.refresh()}catch(e){triggerToast(e.message)}}
  async function handleAdvanceOrderStep(){if(!activeOrder)return;if(orderStep<3){triggerToast('제조 상태를 자동으로 시뮬레이션하고 있어요.');return}try{await api('/api/orders/'+activeOrder.id,{action:'pickup'});setOrderStep(4);await ctx.refresh();triggerToast('수령이 완료되었어요.')}catch(e){triggerToast(e.message)}}

  return (
    <div className="min-h-dvh w-full bg-slate-50 font-sans text-slate-800 flex flex-col antialiased">
      {ctx.sessionReady && !ctx.account && !dismissedLogin && <div role="dialog" aria-modal="true" aria-label="로그인" className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 p-4">
        <div className="relative w-full max-w-md rounded-3xl bg-white shadow-xl">
          <button type="button" aria-label="로그인 창 닫기" onClick={()=>setDismissedLogin(true)} className="absolute right-6 top-6 z-10 rounded-lg p-1 text-slate-500"><X size={20}/></button>
          <AccountPanel account={ctx.account} onLogin={ctx.login} onRegister={ctx.register} onLogout={ctx.logout} onCredit={ctx.credit}/>
        </div>
      </div>}
      {/* Main Layout Area */}
      <main className="w-full flex-1 flex">
        <div 
          data-view={viewMode} className="preview-frame bg-slate-50 relative flex min-h-dvh w-full flex-col"
        >

          <header className="edy-header"><a className="edy-logo" href="/EDY/" aria-label="어디야커피 브랜드 홈페이지"><img src="/EDY/logo-text.png" alt="EODIYA COFFEE 어디야커피" /></a><nav aria-label="주문 사이트 메뉴"><a href="/EDY/">브랜드 홈</a><button className={activeTab==='order'?'selected':''} onClick={()=>setActiveTab('order')}>메뉴 주문</button><button className={activeTab==='home'?'selected':''} onClick={()=>setActiveTab('home')}>멤버십</button></nav><span className="edy-store"><MapPin size={14}/>{STORE_NAME}</span></header><section className="edy-intro"><div><p>EODIYA ORDER</p><h1>오늘의 한 잔을 골라보세요.</h1><span>당신의 취향대로, 어디야커피.</span></div><a href="/EDY/">브랜드 이야기 만나기 ↗</a></section>
          {ctx.error&&<div role="alert" className="bg-red-50 p-3 text-xs text-red-700">{ctx.error}<button onClick={ctx.refresh}> 다시 연결</button></div>}
          <div className="text-center text-[10px] bg-sky-50 text-sky-800 py-1">과제용 {ctx.config.mode==='demo'?'브라우저 저장 · 체험 결제 · 실제 청구 없음':'토스 테스트 결제'}</div>
          {/* SCREEN CONTENT CONTAINER */}
          <div className="flex-1 relative pb-24">
            
            {activeTab === 'home' && (
              <><div className="grid grid-cols-2 gap-2 p-4 pb-0">{[['pickup','픽업 주문'],['delivery','딜리버리 체험']].map(([id,label])=><button key={id} onClick={()=>ctx.setMode(id)} className={'rounded-xl p-3 text-xs font-bold '+(ctx.mode===id?'bg-sky-500 text-white':'bg-white text-slate-600')}>{label}</button>)}</div><HomeScreen account={ctx.account}
                userTier={userTier} 
                stamps={stamps} 
                balance={daelimPayBalance}
                coupons={coupons}
                onNavigate={(tab) => setActiveTab(tab)}
                onSelectMenu={(menu) => {
                  setActiveTab('order');
                  setCustomizingItem(menu);
                }}
                activeOrder={activeOrder}
                orderStep={orderStep}
                onOpenTopUp={() => setShowTopUpModal(true)}
              /></>
            )}

            {activeTab === 'order' && (
              <OrderScreen 
                selectedCategory={selectedCategory}
                setSelectedCategory={setSelectedCategory}
                searchQuery={searchQuery}
                setSearchQuery={setSearchQuery}
                onSelectMenu={(menu) => setCustomizingItem(menu)}
              />
            )}

            {activeTab === 'coupon' && (
              <><button onClick={()=>setShowTopUpModal(true)} className="m-4 mb-0 rounded-xl bg-sky-500 text-white p-3 text-xs font-bold">+ 쿠폰 · 상품권 등록</button><CouponStampScreen 
                stamps={stamps}
                coupons={coupons}
                onUseCoupon={(coupon) => {
                  setAppliedCoupon(coupon);
                  setActiveTab('checkout');
                }}
                onShowBarcode={(coupon) => setShowBarcodeModal({ title: coupon.name, code: coupon.code })}
              /></>
            )}

            {activeTab === 'pay' && (
              <DaelimPayScreen 
                balance={daelimPayBalance}
                onOpenTopUp={() => setShowTopUpModal(true)}
                onShowBarcode={() => setShowBarcodeModal({ title: '어디야커피 Pay 결제 바코드', code: 'EODIYA-PAY-2026-7788' })}
              />
            )}

            {activeTab === 'my' && (
              <><AccountPanel account={ctx.account} onLogin={ctx.login} onRegister={ctx.register} onLogout={ctx.logout} onCredit={ctx.credit}/><MyPageScreen 
                account={ctx.account}
                userTier={userTier}
                stamps={stamps}
                balance={daelimPayBalance}
                couponCount={coupons.length}
              /><section className="p-4 space-y-2"><h3 className="font-bold text-sm">주문 내역</h3>{ctx.member?.orders.filter(o=>o.status==='paid').map(o=><a className="block bg-white rounded-xl border border-sky-100 p-3 text-xs" key={o.id} href="#status" onClick={async e=>{e.preventDefault();try{adaptOrder((await api('/api/orders/'+o.id)).order);setActiveTab('status')}catch(err){triggerToast(err.message)}}}><b>픽업 {o.number} · {o.amount.toLocaleString()}원</b><p className="mt-1 text-slate-500">{new Date(o.created).toLocaleString('ko-KR')} · {o.pickedAt?'수령 완료':'진행 중'}</p></a>)}{!ctx.member?.orders.some(o=>o.status==='paid')&&<p className="text-xs text-slate-500">아직 주문 내역이 없습니다.</p>}</section></>
            )}

            {activeTab === 'checkout' && (
              <>{ctx.mode==='delivery'&&<label className="block p-4 text-xs">체험 배달 주소 · 배달비 2,500원<input className="w-full mt-2 border rounded-xl p-3" value={address} onChange={e=>setAddress(e.target.value)} maxLength={200} placeholder="예: 학생회관 1층" disabled={!!pending}/></label>}{paymentError&&<p role="alert" className="m-4 p-3 bg-red-50 text-red-700 text-xs rounded-xl">{paymentError}</p>}{pending&&<button className="m-4 text-xs text-sky-700 underline" onClick={cancelPending}>대기 주문 취소 후 다시 선택</button>}<fieldset disabled={isProcessing||!!pending} className="disabled:opacity-70"><CheckoutScreen 
                account={ctx.account}
                cart={cart}
                cartSubtotal={cartSubtotal}
                couponDiscount={couponDiscount}
                cartTotal={cartTotal}
                appliedCoupon={appliedCoupon}
                setAppliedCoupon={setAppliedCoupon}
                coupons={coupons}
                payMethod={payMethod}
                setPayMethod={setPayMethod}
                daelimPayBalance={daelimPayBalance}
                onUpdateQty={handleUpdateQty}
                onProcessPayment={handleCheckout}
                isProcessing={isProcessing||!ctx.member}
                onBack={() => setActiveTab('order')}
                onOpenTopUp={() => setShowTopUpModal(true)}
                applePay={ctx.config.applePay}
              /></fieldset>{pending&&<button disabled={isProcessing} onClick={handleCheckout} className="m-4 bg-sky-500 text-white rounded-xl p-3 text-sm">같은 주문 결제 다시 확인</button>}</>
            )}

            {activeTab === 'status' && (
              <PickupStatusScreen 
                activeOrder={activeOrder}
                orderStep={orderStep}
                onAdvanceStep={handleAdvanceOrderStep}
                onGoHome={() => setActiveTab('home')}
              />
            )}
          </div>

          {/* FLOATING CART CHECKOUT BAR */}
          {cart.length > 0 && activeTab === 'order' && (
            <div className="fixed bottom-20 left-4 right-4 z-30 animate-in slide-in-from-bottom duration-200">
              <button 
                onClick={() => setActiveTab('checkout')}
                className="w-full bg-[#3B82F6] text-white py-3.5 px-5 rounded-2xl shadow-xl flex justify-between items-center hover:bg-blue-600 transition active:scale-[0.99]"
              >
                <div className="flex items-center gap-2.5">
                  <div className="bg-white text-blue-600 font-black w-6 h-6 rounded-full flex items-center justify-center text-xs shadow-xs">
                    {cart.reduce((s, i) => s + i.quantity, 0)}
                  </div>
                  <span className="font-bold text-sm">장바구니 주문하기</span>
                </div>
                <span className="font-black text-sky-100 text-base">
                  {cartTotal.toLocaleString()}원 결제
                </span>
              </button>
            </div>
          )}

          {/* BOTTOM NAVIGATION */}
          <div className="bg-white border-t border-slate-200 h-16 flex justify-around items-center px-2 fixed bottom-0 left-0 right-0 z-40 shadow-lg">
            <NavButton 
              icon={<Home className="w-5 h-5" />} 
              label="홈" 
              isActive={activeTab === 'home'} 
              onClick={() => setActiveTab('home')} 
            />
            <NavButton 
              icon={<Coffee className="w-5 h-5" />} 
              label="주문" 
              isActive={activeTab === 'order'} 
              onClick={() => setActiveTab('order')} 
            />
            <NavButton 
              icon={<Ticket className="w-5 h-5" />} 
              label="스탬프/쿠폰" 
              isActive={activeTab === 'coupon'} 
              badge={coupons.length}
              onClick={() => setActiveTab('coupon')} 
            />
            <NavButton 
              icon={<CreditCard className="w-5 h-5" />} 
              label="어디야 Pay" 
              isActive={activeTab === 'pay'} 
              onClick={() => setActiveTab('pay')} 
            />
            <NavButton 
              icon={<User className="w-5 h-5" />} 
              label="마이" 
              isActive={activeTab === 'my'} 
              onClick={() => setActiveTab('my')} 
            />
          </div>

        </div>
      </main>

      {/* TOAST BANNER */}
      {toastMessage && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 bg-slate-900/90 text-white text-xs px-4 py-2.5 rounded-full shadow-2xl flex items-center gap-2 border border-slate-700 backdrop-blur-md animate-in fade-in">
          <Sparkles className="w-4 h-4 text-sky-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* CUSTOMIZING OPTION MODAL */}
      {customizingItem && (
        <CustomizingModal 
          item={customizingItem}
          onClose={() => setCustomizingItem(null)}
          onAddToCart={handleAddToCart}
        />
      )}

      {/* CARD TOP-UP MODAL */}
      {showTopUpModal && (
        <CardTopUpModal 
          currentBalance={daelimPayBalance}
          onTopUp={async(code)=>{const result=await api('/api/redeem',{code});await ctx.refresh();setShowTopUpModal(false);triggerToast(result.message)}}
          onClose={() => setShowTopUpModal(false)}
        />
      )}

      {/* BARCODE MODAL */}
      {showBarcodeModal && (
        <BarcodeModal 
          data={showBarcodeModal}
          onClose={() => setShowBarcodeModal(null)}
        />
      )}

    </div>
  );
}

// Nav Button
function NavButton({ icon, label, isActive, badge, onClick }) {
  return (
    <button 
      onClick={onClick}
      className={`flex flex-col items-center justify-center w-full py-1 relative transition-colors ${
        isActive ? 'text-sky-600 font-bold' : 'text-slate-400 hover:text-slate-600'
      }`}
    >
      <div className="relative">
        {icon}
        {badge > 0 && (
          <span className="absolute -top-1 -right-2 bg-sky-500 text-white text-[9px] w-3.5 h-3.5 rounded-full flex items-center justify-center font-black">
            {badge}
          </span>
        )}
      </div>
      <span className="text-[11px] mt-1">{label}</span>
      {isActive && <span className="w-1.5 h-1.5 bg-sky-600 rounded-full absolute bottom-0"></span>}
    </button>
  );
}

// ==========================================
// 1. HOME SCREEN
// ==========================================
function HomeScreen({ account, userTier, stamps, balance, coupons, onNavigate, onSelectMenu, activeOrder, orderStep, onOpenTopUp }) {
  return (
    <div className="home-screen space-y-4 p-4">
      
      {/* ACTIVE ORDER LIVE TRACKER BANNER */}
      {activeOrder && orderStep < 4 && (
        <div 
          onClick={() => onNavigate('status')}
          className="bg-gradient-to-r from-sky-500 to-sky-600 text-white p-3.5 rounded-2xl shadow-md flex items-center justify-between cursor-pointer hover:brightness-105 transition"
        >
          <div className="flex items-center gap-3">
            <div className="bg-white p-2 rounded-xl text-sky-600 animate-bounce">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-sky-200 font-extrabold flex items-center gap-1">
                <span>실시간 주문 진행 중</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-300 animate-ping"></span>
              </div>
              <div className="text-sm font-black">
                주문번호 [{activeOrder.orderId}] - {orderStep === 1 ? '주문 접수' : orderStep === 2 ? '음료 제조 중' : '픽업 대기'}
              </div>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-sky-200" />
        </div>
      )}

      {/* USER PROFILE CARD */}
      <div className="bg-white p-4 rounded-2xl shadow-xs border border-sky-100 flex justify-between items-center">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] bg-sky-100 text-sky-800 font-black px-2.5 py-0.5 rounded-full border border-sky-200">
              {userTier} EODIYA MEMBER
            </span>
            <span className="text-xs text-slate-400 font-medium">대림대학교</span>
          </div>
          <h2 className="text-lg font-black text-slate-800 mt-1.5">
            {account?.id || '어디야 멤버'} <span className="font-normal text-xs text-slate-500">님, 반갑습니다!</span>
          </h2>
        </div>
        <div className="text-right shrink-0 whitespace-nowrap">
          <div className="text-[11px] text-slate-400">어디야 Pay 잔액</div>
          <div className="text-base font-black text-sky-600">
            {balance.toLocaleString()}원
          </div>
        </div>
      </div>

      {/* STAMP CARD - SOFT SKY BLUE PALETTE */}
      <div className="bg-gradient-to-br from-sky-500 via-sky-500 to-sky-600 text-white p-5 rounded-3xl shadow-lg relative overflow-hidden border border-sky-300/30">
        <div className="flex justify-between items-start mb-3">
          <div>
            <div className="text-sky-200 font-extrabold text-xs flex items-center gap-1">
              <GraduationCap className="w-4 h-4" /> EODIYA STAMP CARD
            </div>
            <h3 className="text-xl font-black mt-1">
              스탬프 <span className="text-sky-200">{stamps}</span> / 12개
            </h3>
          </div>
          <button 
            onClick={() => onNavigate('coupon')}
            className="text-xs bg-white/20 hover:bg-white/30 text-white px-3 py-1.5 rounded-full flex items-center gap-1 backdrop-blur-sm border border-white/20"
          >
            쿠폰함 ({coupons.length}) <ChevronRight className="w-3 h-3" />
          </button>
        </div>

        {/* 12 Stamp Grid */}
        <div className="grid grid-cols-6 gap-2 my-3 bg-sky-950/20 p-3 rounded-2xl border border-white/10">
          {Array.from({ length: 12 }).map((_, i) => {
            const isEarned = i < stamps;
            const isTarget = i === 11;
            return (
              <div 
                key={i}
                className={`aspect-square rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                  isEarned 
                    ? 'bg-white text-sky-600 shadow-md scale-105' 
                    : 'bg-white/10 text-sky-100/50 border border-white/10'
                }`}
              >
                {isEarned ? (
                  <Coffee className="w-4 h-4 text-sky-600" />
                ) : isTarget ? (
                  <Gift className="w-4 h-4 text-sky-200 animate-pulse" />
                ) : (
                  <span className="text-[10px]">{i + 1}</span>
                )}
              </div>
            );
          })}
        </div>

        <div className="flex justify-between items-center text-[11px] text-sky-100 bg-sky-900/40 px-3 py-1.5 rounded-xl border border-sky-300/20">
          <span>💡 12개 완성 시 <strong className="text-white">무료 아메리카노</strong> 쿠폰 증정</span>
          <span className="font-extrabold text-sky-200">남은 스탬프 {12 - stamps}개</span>
        </div>
      </div>

      {/* QUICK ACTIONS */}
      <div className="grid grid-cols-2 gap-3">
        <button 
          onClick={() => onNavigate('order')}
          className="bg-gradient-to-br from-sky-500 to-sky-500 text-white p-4 rounded-2xl shadow-xs text-left flex flex-col justify-between h-28 hover:brightness-105 active:scale-95 transition"
        >
          <div className="bg-white/20 w-9 h-9 rounded-xl flex items-center justify-center backdrop-blur-md">
            <Coffee className="w-5 h-5 text-white" />
          </div>
          <div>
            <span className="text-xs text-sky-100 block font-medium">캠퍼스 빠른 픽업</span>
            <span className="font-black text-base">어디야커피 오더</span>
          </div>
        </button>

        <button 
          onClick={onOpenTopUp}
          className="bg-white border border-sky-100 text-slate-800 p-4 rounded-2xl shadow-xs text-left flex flex-col justify-between h-28 hover:bg-sky-50/50 active:scale-95 transition"
        >
          <div className="bg-sky-100 w-9 h-9 rounded-xl flex items-center justify-center">
            <CreditCard className="w-5 h-5 text-sky-600" />
          </div>
          <div>
            <span className="text-xs text-slate-400 block font-medium">잔액 충전 / 카드</span>
            <span className="font-black text-base text-sky-600">어디야 Pay</span>
          </div>
        </button>
      </div>

      {/* POPULAR MENU GRID */}
      <div className="bg-white p-4 rounded-2xl shadow-xs border border-sky-100">
        <div className="flex justify-between items-center mb-3">
          <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-1.5">
            <Zap className="w-4 h-4 text-sky-500 fill-sky-500" />
            어디야 추천 인기 메뉴
          </h3>
          <button 
            onClick={() => onNavigate('order')} 
            className="text-xs text-slate-400 hover:text-slate-600 flex items-center"
          >
            전체보기 <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {MENU_ITEMS.filter(m => m.popular).slice(0, 4).map((item) => (
            <div 
              key={item.id}
              onClick={() => onSelectMenu(item)}
              className="bg-sky-50/40 border border-sky-100 p-3 rounded-2xl cursor-pointer hover:border-sky-400 transition flex flex-col justify-between"
            >
              <div className="text-3xl text-center my-2"><ProductVisual item={item} /></div>
              <div>
                {item.badge && (
                  <span className="text-[9px] bg-sky-100 text-sky-800 font-black px-1.5 py-0.5 rounded border border-sky-200">
                    {item.badge}
                  </span>
                )}
                <div className="font-bold text-xs text-slate-800 mt-1 line-clamp-1">{item.name}</div>
                <div className="font-black text-xs text-sky-600 mt-0.5">
                  {item.price.toLocaleString()}원
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 2. ORDER SCREEN
// ==========================================
function OrderScreen({ selectedCategory, setSelectedCategory, searchQuery, setSearchQuery, onSelectMenu }) {
  const filteredItems = MENU_ITEMS.filter((item) => {
    const matchesCategory = selectedCategory === '추천메뉴' ? item.popular : item.category === selectedCategory;
    const matchesSearch = item.name.includes(searchQuery) || item.nameEn.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="flex flex-col h-full">
      {/* Header Bar */}
      <div className="bg-white p-3 border-b border-sky-100 sticky top-0 z-10 shadow-xs space-y-2.5">
        <div className="flex items-center justify-between text-xs text-slate-600 bg-sky-50/70 p-2.5 rounded-xl border border-sky-100">
          <div className="flex items-center gap-2 font-bold text-slate-800">
            <MapPin className="w-4 h-4 text-sky-600 shrink-0" />
            <span className="truncate">{STORE_NAME}</span>
          </div>
          <span className="text-[10px] bg-white px-2 py-0.5 rounded-full font-extrabold text-sky-600 border border-sky-200">
            캠퍼스 단독 매장
          </span>
        </div>

        {/* Input Bar */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input 
            type="text" 
            aria-label="메뉴 검색" placeholder="음료 또는 디저트 검색..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-100 text-xs pl-10 pr-8 py-2.5 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500 border border-transparent"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="absolute right-3 top-2.5 text-slate-400">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Categories */}
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`text-xs px-3.5 py-1.5 rounded-full whitespace-nowrap font-bold transition ${
                selectedCategory === cat 
                  ? 'bg-sky-500 text-white shadow-xs' 
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Menu Item Cards */}
      <div className="menu-list p-4 space-y-3 flex-1">
        {filteredItems.length === 0 ? (
          <div className="text-center py-16 text-slate-400 text-xs">
            검색어에 해당하는 메뉴가 존재하지 않습니다.
          </div>
        ) : (
          filteredItems.map((item) => (
            <div 
              key={item.id}
              onClick={() => onSelectMenu(item)}
              className="bg-white p-3.5 rounded-2xl shadow-xs border border-slate-200/70 flex items-center justify-between cursor-pointer hover:border-sky-400 transition active:scale-[0.99]"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-16 h-16 bg-sky-50 rounded-xl flex items-center justify-center text-3xl shrink-0 border border-sky-100">
                  <ProductVisual item={item} />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold text-xs text-slate-800">{item.name}</span>
                    {item.badge && (
                      <span className="text-[8px] bg-sky-100 text-sky-800 font-black px-1.5 py-0.2 rounded border border-sky-200">
                        {item.badge}
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">{item.description}</div>
                  <div className="font-black text-xs text-sky-600 mt-1.5">
                    {item.price.toLocaleString()}원
                  </div>
                </div>
              </div>
              <button aria-label={item.name+' 옵션 선택'} className="bg-sky-50 hover:bg-sky-500 hover:text-white p-2.5 rounded-full text-sky-600 transition shrink-0 ml-2">
                <Plus className="w-4 h-4" />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

// Customizing Modal
function CustomizingModal({ item, onClose, onAddToCart }) {
  const [temperature, setTemperature] = useState(item.isHotIce ? 'ICE' : 'ICE');
  const [cupType, setCupType] = useState('일회용컵');
  const [size, setSize] = useState('REGULAR');
  const [extraShots, setExtraShots] = useState(0);
  const [vanillaSyrup, setVanillaSyrup] = useState(0);
  const [sweetness,setSweetness]=useState('기본');
  const [iceAmount, setIceAmount] = useState('보통');
  const [quantity, setQuantity] = useState(1);

  const sizePrice = size === 'EXTRA' ? 1200 : 0;
  const shotPrice = extraShots * 500;
  const syrupPrice = vanillaSyrup * 500;
  const cupDiscount = cupType === '개인컵' ? -300 : 0;

  const singleUnitPrice = item.drink ? Math.max(0, item.price + sizePrice + shotPrice + syrupPrice + cupDiscount) : item.price;
  const totalPrice = singleUnitPrice * quantity;

  const handleConfirm = () => {
    onAddToCart({
      ...item,
      temperature: item.isHotIce ? temperature : 'ICE',
      cupType,
      size,
      extraShots,
      vanillaSyrup, sweetness,
      iceAmount,
      quantity,
      unitPrice: singleUnitPrice,
      totalPrice
    });
  };

  return (
    <div role="dialog" aria-modal="true" aria-label="메뉴 옵션" className="fixed inset-0 bg-slate-900/60 z-50 flex items-end sm:items-center justify-center backdrop-blur-xs p-0 sm:p-4 animate-in fade-in">
      <div className="bg-white w-full sm:max-w-[420px] rounded-t-3xl sm:rounded-3xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
        
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-sky-50/50">
          <h3 className="font-black text-sm text-slate-800">옵션 선택</h3>
          <button aria-label="옵션 닫기" onClick={onClose} className="p-1 rounded-full hover:bg-slate-200 text-slate-500">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Options */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1 text-xs">
          <div className="flex items-center gap-3 bg-sky-50 p-3 rounded-2xl border border-sky-100">
            <span className="text-3xl"><ProductVisual item={item} /></span>
            <div>
              <div className="font-extrabold text-sm text-slate-800">{item.name}</div>
              <div className="text-[11px] text-slate-500">{item.nameEn}</div>
              <div className="font-black text-xs text-sky-600 mt-0.5">
                기본가 {item.price.toLocaleString()}원
              </div>
            </div>
          </div>

          {item.drink&&<>{/* HOT / ICE */}
          {item.isHotIce && (
            <div>
              <label className="font-bold text-slate-700 block mb-1.5">온도 선택</label>
              <div className="grid grid-cols-2 gap-2">
                <button 
                  onClick={() => setTemperature('HOT')}
                  className={`py-2.5 rounded-xl font-extrabold border transition ${
                    temperature === 'HOT' 
                      ? 'bg-rose-500 text-white border-rose-500 shadow-xs' 
                      : 'bg-white text-slate-600 border-slate-200'
                  }`}
                >
                  🔥 HOT
                </button>
                <button 
                  onClick={() => setTemperature('ICE')}
                  className={`py-2.5 rounded-xl font-extrabold border transition ${
                    temperature === 'ICE' 
                      ? 'bg-sky-500 text-white border-sky-500 shadow-xs' 
                      : 'bg-white text-slate-600 border-slate-200'
                  }`}
                >
                  🧊 ICE
                </button>
              </div>
            </div>
          )}

          {/* Cup */}
          <div>
            <label className="font-bold text-slate-700 block mb-1.5">컵 종류</label>
            <div className="grid grid-cols-3 gap-2">
              {['매장컵', '일회용컵', '개인컵'].map((type) => (
                <button
                  key={type}
                  onClick={() => setCupType(type)}
                  className={`py-2 rounded-xl font-bold border transition ${
                    cupType === type 
                      ? 'bg-sky-500 text-white border-sky-500' 
                      : 'bg-white text-slate-600 border-slate-200'
                  }`}
                >
                  {type}
                  {type === '개인컵' && <span className="block text-[9px] text-sky-200 font-normal">-300원 할인</span>}
                </button>
              ))}
            </div>
          </div>

          {/* Size */}
          <div>
            <label className="font-bold text-slate-700 block mb-1.5">사이즈</label>
            <div className="grid grid-cols-2 gap-2">
              <button 
                onClick={() => setSize('REGULAR')}
                className={`p-3 rounded-xl text-left border transition ${
                  size === 'REGULAR' ? 'border-sky-500 bg-sky-50/50 ring-1 ring-sky-500' : 'border-slate-200'
                }`}
              >
                <div className="font-extrabold text-slate-800">REGULAR</div>
                <div className="text-[10px] text-slate-400">기본 사이즈</div>
              </button>
              <button 
                onClick={() => setSize('EXTRA')}
                className={`p-3 rounded-xl text-left border transition ${
                  size === 'EXTRA' ? 'border-sky-500 bg-sky-50/50 ring-1 ring-sky-500' : 'border-slate-200'
                }`}
              >
                <div className="font-extrabold text-slate-800">EXTRA (+1,200원)</div>
                <div className="text-[10px] text-slate-400">대용량 엑스트라</div>
              </button>
            </div>
          </div>

          <div><label className="font-bold text-slate-700 block mb-2">기본 시럽 조절</label><div className="grid grid-cols-3 gap-2">{['기본','적게','없이'].map(v=><button key={v} onClick={()=>setSweetness(v)} className={'rounded-xl border py-2 '+(sweetness===v?'bg-sky-500 text-white border-sky-500':'border-slate-200')}>{v}</button>)}</div></div>{/* Customizations */}
          <div className="space-y-2.5 pt-2 border-t border-slate-100">
            <span className="font-bold text-slate-700 block">퍼스널 옵션</span>

            <div className="flex justify-between items-center bg-slate-50 p-2.5 rounded-xl">
              <div>
                <span className="font-bold text-slate-800">샷 추가 (+500원)</span>
                <span className="text-[10px] text-slate-400 block">더 진한 에스프레소</span>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => setExtraShots(Math.max(0, extraShots - 1))} className="w-6 h-6 bg-white rounded-md border font-bold text-slate-600">-</button>
                <span className="font-black w-4 text-center">{extraShots}</span>
                <button onClick={() => setExtraShots(Math.min(3,extraShots + 1))} className="w-6 h-6 bg-white rounded-md border font-bold text-slate-600">+</button>
              </div>
            </div>

            <div className="flex justify-between items-center bg-slate-50 p-2.5 rounded-xl">
              <div>
                <span className="font-bold text-slate-800">바닐라 시럽 (+500원)</span>
                <span className="text-[10px] text-slate-400 block">달콤한 향 추가</span>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => setVanillaSyrup(Math.max(0, vanillaSyrup - 1))} className="w-6 h-6 bg-white rounded-md border font-bold text-slate-600">-</button>
                <span className="font-black w-4 text-center">{vanillaSyrup}</span>
                <button onClick={() => setVanillaSyrup(Math.min(3,vanillaSyrup + 1))} className="w-6 h-6 bg-white rounded-md border font-bold text-slate-600">+</button>
              </div>
            </div>

            <div className="flex justify-between items-center bg-slate-50 p-2.5 rounded-xl">
              <span className="font-bold text-slate-800">얼음 양</span>
              <div className="flex gap-1">
                {['적게', '보통', '많이'].map((ice) => (
                  <button
                    key={ice}
                    onClick={() => setIceAmount(ice)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold border transition ${
                      iceAmount === ice ? 'bg-sky-500 text-white border-sky-500' : 'bg-white text-slate-600 border-slate-200'
                    }`}
                  >
                    {ice}
                  </button>
                ))}
              </div>
            </div>
          </div>

          </>}{/* Quantity */}
          <div className="flex justify-between items-center pt-3 border-t border-slate-100">
            <span className="font-bold text-slate-800">수량</span>
            <div className="flex items-center gap-3 bg-slate-100 p-1 rounded-xl">
              <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="w-7 h-7 rounded-lg bg-white flex items-center justify-center font-bold text-slate-700 shadow-xs">
                <Minus className="w-3.5 h-3.5" />
              </button>
              <span className="font-black text-sm w-5 text-center">{quantity}</span>
              <button onClick={() => setQuantity(Math.min(20,quantity + 1))} className="w-7 h-7 rounded-lg bg-white flex items-center justify-center font-bold text-slate-700 shadow-xs">
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-white">
          <button 
            onClick={handleConfirm}
            className="w-full bg-sky-500 text-white py-3.5 rounded-2xl font-black text-xs flex justify-between px-5 hover:bg-sky-600 transition shadow-md"
          >
            <span>장바구니 담기</span>
            <span className="text-sky-100">{totalPrice.toLocaleString()}원</span>
          </button>
        </div>

      </div>
    </div>
  );
}

// ==========================================
// 3. CHECKOUT SCREEN
// ==========================================
function CheckoutScreen({ 
  cart, cartSubtotal, couponDiscount, cartTotal, appliedCoupon, setAppliedCoupon, 
  coupons, payMethod, setPayMethod, daelimPayBalance, onUpdateQty, onProcessPayment, isProcessing, onBack, onOpenTopUp, applePay, account
}) {
  return (
    <div className="p-4 space-y-4 pb-28">
      <div className="flex items-center gap-2">
        <button onClick={onBack} className="p-1.5 bg-white rounded-full border border-slate-200 hover:bg-slate-50">
          <ArrowLeft className="w-4 h-4 text-slate-700" />
        </button>
        <h2 className="font-extrabold text-base text-slate-800">장바구니 및 결제</h2>
      </div>
      {!account ? <p className="rounded-xl bg-sky-50 p-3 text-xs text-sky-800">주문하려면 먼저 로그인해주세요.</p> : cartTotal > daelimPayBalance && <p role="alert" className="rounded-xl bg-red-50 p-3 text-xs text-red-700">잔액이 부족합니다. 관리자에게 충전을 요청해주세요.</p>}

      {cart.length === 0 ? (
        <div className="bg-white rounded-2xl p-10 text-center border border-slate-200/80 space-y-3">
          <ShoppingBag className="w-12 h-12 text-slate-300 mx-auto" />
          <div className="text-sm font-bold text-slate-600">장바구니가 비어 있습니다.</div>
          <button onClick={onBack} className="text-xs bg-sky-500 text-white px-4 py-2.5 rounded-xl font-bold">
            메뉴 주문하러 가기
          </button>
        </div>
      ) : (
        <>
          {/* Pickup Store Banner */}
          <div className="bg-sky-50 p-3.5 rounded-2xl border border-sky-200 flex justify-between items-center text-xs">
            <div>
              <span className="text-[10px] font-extrabold text-sky-600 uppercase">픽업 장소</span>
              <div className="font-extrabold text-slate-800 mt-0.5">{STORE_NAME}</div>
            </div>
            <span className="text-[10px] bg-white text-sky-700 font-bold px-2 py-0.5 rounded-full border border-sky-200">
              대림대 캠퍼스 픽업
            </span>
          </div>

          {/* Cart Items */}
          <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-3">
            <h3 className="font-extrabold text-xs text-slate-400 uppercase tracking-wider">주문 내역</h3>
            {cart.map((item) => (
              <div key={item.cartId} className="flex justify-between items-start border-b border-slate-100 pb-3 last:border-0 last:pb-0">
                <div className="flex items-start gap-3">
                  <span className="text-2xl pt-1"><ProductVisual item={item} /></span>
                  <div>
                    <div className="font-bold text-xs text-slate-800">{item.name}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      {item.temperature} | {item.cupType} | {item.size}
                      {item.extraShots > 0 && ` | 샷+${item.extraShots}`}
                      {item.vanillaSyrup > 0 && ` | 시럽+${item.vanillaSyrup}`}
                      {` | 얼음:${item.iceAmount}`}
                    </div>
                    <div className="font-black text-xs text-sky-600 mt-1">
                      {item.totalPrice.toLocaleString()}원
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 bg-slate-100 px-2 py-1 rounded-lg">
                  <button onClick={() => onUpdateQty(item.cartId, -1)} className="text-xs font-bold text-slate-600 px-1 hover:text-rose-500">
                    -
                  </button>
                  <span className="text-xs font-black">{item.quantity}</span>
                  <button onClick={() => onUpdateQty(item.cartId, 1)} className="text-xs font-bold text-slate-600 px-1 hover:text-sky-600">
                    +
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Coupons */}
          <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-2">
            <label className="font-bold text-xs text-slate-700 block">쿠폰 적용</label>
            <select
              value={appliedCoupon?.id || ''}
              onChange={(e) => {
                const found = coupons.find((c) => c.id === e.target.value);
                setAppliedCoupon(found || null);
              }}
              className="w-full bg-slate-50 border border-slate-200 text-xs rounded-xl p-2.5 font-bold focus:outline-none focus:ring-1 focus:ring-sky-500"
            >
              <option value="">적용할 쿠폰 선택 안함</option>
              {coupons.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} (-{c.discount.toLocaleString()}원)
                </option>
              ))}
            </select>
          </div>

          {/* Pay Methods */}
          <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-3">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-xs text-slate-700">결제 수단</h3>
              {payMethod === 'EODIYA_PAY' && (
                <button onClick={onOpenTopUp} className="text-[10px] text-sky-600 font-extrabold flex items-center gap-0.5 hover:underline">
                  <PlusCircle className="w-3 h-3" /> 잔액 충전
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button 
                onClick={() => setPayMethod('EODIYA_PAY')}
                className={`p-3 rounded-xl border text-left transition ${
                  payMethod === 'EODIYA_PAY' 
                    ? 'border-sky-500 bg-sky-50 ring-1 ring-sky-500' 
                    : 'border-slate-200'
                }`}
              >
                <div className="font-black text-xs text-sky-600">어디야커피 Pay</div>
                <div className="text-[10px] text-slate-500 mt-1">
                  잔액: {daelimPayBalance.toLocaleString()}원
                </div>
              </button>

              <button 
                onClick={() => setPayMethod('TOSS')}
                className={`p-3 rounded-xl border text-left transition ${
                  payMethod === 'TOSS' 
                    ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-500' 
                    : 'border-slate-200'
                }`}
              >
                <div className="font-black text-xs text-blue-600">토스페이</div>
                <div className="text-[10px] text-slate-400 mt-1">간편 결제</div>
              </button>

              <button 
                onClick={() => setPayMethod('KAKAO')}
                className={`p-3 rounded-xl border text-left transition ${
                  payMethod === 'KAKAO' 
                    ? 'border-yellow-400 bg-amber-50 ring-1 ring-yellow-400' 
                    : 'border-slate-200'
                }`}
              >
                <div className="font-black text-xs text-amber-900">카카오페이</div>
                <div className="text-[10px] text-slate-400 mt-1">카카오머니</div>
              </button>

              <button 
                onClick={() => setPayMethod('CARD')}
                className={`p-3 rounded-xl border text-left transition ${
                  payMethod === 'CARD' 
                    ? 'border-slate-800 bg-slate-50 ring-1 ring-slate-800' 
                    : 'border-slate-200'
                }`}
              >
                <div className="font-black text-xs text-slate-800">신용/체크카드</div>
                <div className="text-[10px] text-slate-400 mt-1">일반 카드 결제</div>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2"><button onClick={()=>setPayMethod('NAVER')} className={'rounded-xl p-3 text-xs border font-bold '+(payMethod==='NAVER'?'bg-green-50 border-green-500':'bg-white border-slate-200')}>네이버페이</button><button disabled={!applePay} onClick={()=>setPayMethod('APPLE')} className={'rounded-xl p-3 text-xs border font-bold disabled:opacity-40 '+(payMethod==='APPLE'?'border-sky-500 bg-sky-50':'bg-white border-slate-200')}>Apple Pay{!applePay&&<small className="block">연동 설정 필요</small>}</button></div>
          {/* Pricing Box */}
          <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-2 text-xs">
            <div className="flex justify-between text-slate-500">
              <span>상품 총액{cartTotal>cartSubtotal-couponDiscount?' + 배달비 2,500원':''}</span>
              <span>{(cartSubtotal+(cartTotal>cartSubtotal-couponDiscount?2500:0)).toLocaleString()}원</span>
            </div>
            {couponDiscount > 0 && (
              <div className="flex justify-between text-rose-500 font-semibold">
                <span>쿠폰 할인</span>
                <span>-{couponDiscount.toLocaleString()}원</span>
              </div>
            )}
            <div className="border-t border-slate-100 pt-2 flex justify-between font-black text-sm text-slate-800">
              <span>최종 결제 금액</span>
              <span className="text-sky-600 text-base">{cartTotal.toLocaleString()}원</span>
            </div>
          </div>

          <button 
            disabled={isProcessing}
            onClick={onProcessPayment}
            className="w-full bg-sky-500 hover:bg-sky-600 text-white py-4 rounded-2xl font-black text-sm shadow-lg transition flex justify-center items-center gap-2 disabled:opacity-50"
          >
            {isProcessing ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>주문 승인 처리 중...</span>
              </>
            ) : (
              <span>{cartTotal.toLocaleString()}원 결제 완료하기</span>
            )}
          </button>
        </>
      )}
    </div>
  );
}

// ==========================================
// 4. PICKUP STATUS SCREEN
// ==========================================
function PickupStatusScreen({ activeOrder, orderStep, onAdvanceStep, onGoHome }) {
  if (!activeOrder) {
    return (
      <div className="p-8 text-center space-y-3">
        <Info className="w-12 h-12 text-slate-300 mx-auto" />
        <div className="text-sm text-slate-600 font-bold">진행 중인 주문 내역이 없습니다.</div>
        <button onClick={onGoHome} className="bg-sky-500 text-white text-xs px-4 py-2.5 rounded-xl font-bold">
          홈으로 가기
        </button>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
      {/* Banner */}
      <div className="bg-gradient-to-br from-sky-500 to-sky-500 text-white p-5 rounded-3xl text-center space-y-1 shadow-lg">
        <div className="text-xs text-sky-200 font-bold">어디야커피 픽업 번호</div>
        <div className="text-4xl font-black tracking-widest text-white my-1">{activeOrder.orderId}</div>
        <div className="text-xs text-sky-100">{STORE_NAME}</div>
      </div>

      {/* Tracker Dashboard */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-6">
        <div className="flex justify-between items-center border-b border-slate-100 pb-2">
          <h3 className="font-black text-xs text-slate-700 uppercase">제조 진행 상태</h3>
          <button 
            onClick={onAdvanceStep}
            disabled={orderStep !== 3}
            className="text-[10px] bg-sky-100 hover:bg-sky-200 text-sky-800 font-black px-2.5 py-1 rounded-lg transition disabled:opacity-40"
          >
            {orderStep===3?'수령 확인':'자동 갱신'}
          </button>
        </div>

        <div className="relative flex justify-between items-center px-2">
          <div className="absolute top-1/2 left-6 right-6 h-1 bg-slate-100 -translate-y-1/2 z-0">
            <div 
              className="h-full bg-sky-500 transition-all duration-500"
              style={{ width: orderStep === 1 ? '0%' : orderStep === 2 ? '50%' : '100%' }}
            ></div>
          </div>

          {[
            { step: 1, label: '주문 접수' },
            { step: 2, label: '음료 준비 중' },
            { step: 3, label: '픽업 대기' }
          ].map((s) => {
            const isPassed = orderStep >= s.step;
            const isCurrent = orderStep === s.step;
            return (
              <div key={s.step} className="relative z-10 flex flex-col items-center">
                <div 
                  className={`w-9 h-9 rounded-full flex items-center justify-center font-black text-xs transition-all ${
                    isPassed 
                      ? 'bg-sky-500 text-white shadow-md' 
                      : 'bg-slate-200 text-slate-400'
                  } ${isCurrent && s.step === 2 ? 'animate-bounce' : ''}`}
                >
                  {isPassed ? <Check className="w-4 h-4" /> : s.step}
                </div>
                <span className={`text-[11px] font-extrabold mt-2 ${isPassed ? 'text-slate-800' : 'text-slate-400'}`}>
                  {s.label}
                </span>
              </div>
            );
          })}
        </div>

        <div className="bg-sky-50 p-3.5 rounded-xl text-center border border-sky-100">
          <p className="text-xs font-black text-sky-700">
            {orderStep === 1 && '매장에서 주문 확인 단계입니다.'}
            {orderStep === 2 && '바리스타가 음료를 준비하고 있습니다.'}
            {orderStep === 3 && '🎉 음료가 준비되었습니다! 대림대학교점 카운터에서 수령해 주세요.'}
            {orderStep === 4 && '✅ 수령이 완료된 주문입니다.'}
          </p>
          <p className="text-[10px] text-slate-400 mt-1">주문 시간: {activeOrder.timestamp}</p>
        </div>
      </div>

      {/* Stamp Reward */}
      <div className="bg-sky-50 border border-sky-200 p-3.5 rounded-2xl flex items-center gap-3">
        <Sparkles className="w-5 h-5 text-sky-600 shrink-0" />
        <div className="text-xs text-sky-900">
          주문 완료로 <span className="font-black text-sky-700">스탬프 {activeOrder.earnedStamps}개</span>가 적립되었습니다!
        </div>
      </div>

      <button 
        onClick={onGoHome}
        className="w-full bg-slate-200 hover:bg-slate-300 text-slate-800 py-3 rounded-2xl font-extrabold text-xs"
      >
        홈으로 돌아가기
      </button>
    </div>
  );
}

// ==========================================
// 5. STAMP & COUPON WALLET
// ==========================================
function CouponStampScreen({ stamps, coupons, onUseCoupon, onShowBarcode }) {
  return (
    <div className="p-4 space-y-4">
      <div className="bg-gradient-to-br from-sky-500 to-sky-500 text-white p-5 rounded-3xl space-y-2 shadow-lg">
        <div className="flex justify-between items-center">
          <span className="text-xs text-sky-200 font-black">어디야커피 스탬프</span>
          <span className="text-xs text-sky-100">12개 완성 시 무료 음료</span>
        </div>
        <div className="text-2xl font-black">
          스탬프 <span className="text-sky-200">{stamps}</span> / 12개
        </div>
        <div className="w-full bg-sky-950/40 rounded-full h-3 overflow-hidden border border-sky-300/20">
          <div 
            className="bg-white h-full rounded-full transition-all duration-300"
            style={{ width: `${(stamps / 12) * 100}%` }}
          ></div>
        </div>
      </div>

      <div className="space-y-3">
        <h3 className="font-extrabold text-sm text-slate-800">
          보유 쿠폰 ({coupons.length}장)
        </h3>

        {coupons.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 text-center text-xs text-slate-400 border border-slate-200">
            사용 가능한 쿠폰이 없습니다.
          </div>
        ) : (
          coupons.map((coupon) => (
            <div key={coupon.id} className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex justify-between items-center">
              <div>
                <div className="text-[9px] text-sky-700 font-black bg-sky-50 px-2 py-0.5 rounded inline-block border border-sky-200">
                  EODIYA COUPON
                </div>
                <div className="font-extrabold text-xs text-slate-800 mt-1">{coupon.name}</div>
                <div className="text-[10px] text-slate-400 mt-0.5">유효기간: {coupon.expiry}까지</div>
              </div>
              <div className="flex flex-col gap-1">
                <button 
                  onClick={() => onUseCoupon(coupon)}
                  className="bg-sky-500 hover:bg-sky-600 text-white text-xs font-bold px-3 py-1.5 rounded-xl shrink-0"
                >
                  쿠폰 사용
                </button>
                <button 
                  onClick={() => onShowBarcode(coupon)}
                  className="text-[10px] text-slate-500 hover:text-slate-800 underline font-semibold text-center"
                >
                  바코드 보기
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

// ==========================================
// 6. EODIYA PAY SCREEN
// ==========================================
function DaelimPayScreen({ balance, onOpenTopUp, onShowBarcode }) {
  return (
    <div className="p-4 space-y-4">
      <div className="bg-gradient-to-br from-sky-500 via-sky-500 to-sky-500 text-white p-6 rounded-3xl shadow-xl space-y-6 relative overflow-hidden border border-sky-300/30">
        <div className="flex justify-between items-center">
          <span className="font-black text-sm tracking-wider text-sky-100">EODIYA CARD</span>
          <QrCode className="w-6 h-6 text-white cursor-pointer" onClick={onShowBarcode} />
        </div>

        <div>
          <div className="text-xs text-sky-100">어디야 Pay 카드 잔액</div>
          <div className="text-3xl font-black text-white mt-0.5">
            {balance.toLocaleString()}원
          </div>
        </div>

        <div className="flex justify-between items-end">
          <div className="text-[10px] text-sky-200/80 font-mono tracking-widest">
            9410 - EODIYA - 2026
          </div>
          <button 
            onClick={onShowBarcode}
            className="text-xs bg-white text-sky-700 font-black px-3 py-1.5 rounded-xl flex items-center gap-1 shadow-xs"
          >
            <QrCode className="w-3.5 h-3.5" /> 결제 바코드
          </button>
        </div>
      </div>

      <button 
        onClick={onOpenTopUp}
        className="w-full bg-white border border-slate-200/80 p-4 rounded-2xl shadow-xs font-extrabold text-xs text-sky-600 hover:bg-sky-50 transition flex justify-between items-center"
      >
        <span className="flex items-center gap-2">
          <PlusCircle className="w-4 h-4 text-sky-500" />
          <span>어디야 Pay 잔액 충전하기</span>
        </span>
        <ChevronRight className="w-4 h-4 text-slate-400" />
      </button>
    </div>
  );
}

// ==========================================
// 7. MY PAGE SCREEN
// ==========================================
function MyPageScreen({ userTier, stamps, balance, couponCount, account }) {
  return (
    <div className="p-4 space-y-4">
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 flex items-center gap-3">
        <div className="w-12 h-12 bg-sky-100 text-sky-700 font-black rounded-full flex items-center justify-center text-lg border border-sky-200">
          대
        </div>
        <div>
          <div className="font-extrabold text-base text-slate-800">{account ? account.id : '어디야 멤버'} 님</div>
          <div className="text-xs text-slate-400">{account ? '어디야 계정' : '브라우저 익명 체험 회원'}</div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200/80 divide-y divide-slate-100 text-xs">
        <div className="p-3.5 flex justify-between items-center font-semibold">
          <span className="text-slate-600">회원 등급</span>
          <span className="font-bold text-sky-600">{userTier} MEMBER</span>
        </div>
        <div className="p-3.5 flex justify-between items-center font-semibold">
          <span className="text-slate-600">적립 스탬프</span>
          <span className="font-bold text-sky-600">{stamps}개</span>
        </div>
        <div className="p-3.5 flex justify-between items-center font-semibold">
          <span className="text-slate-600">보유 쿠폰</span>
          <span className="font-bold text-sky-600">{couponCount}장</span>
        </div>
        <div className="p-3.5 flex justify-between items-center font-semibold">
          <span className="text-slate-600">어디야 Pay 잔액</span>
          <span className="font-bold text-sky-600">{balance.toLocaleString()}원</span>
        </div>
        <div className="p-3.5 flex justify-between items-center font-semibold">
          <span className="text-slate-600">이용 매장</span>
          <span className="font-bold text-slate-800">{STORE_NAME}</span>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// MODALS
// ==========================================

function CardTopUpModal({currentBalance,onTopUp,onClose}){const[code,setCode]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false);return <div role="dialog" aria-modal="true" aria-label="쿠폰 및 상품권 등록" className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4"><div className="w-full max-w-sm bg-white rounded-3xl p-5 space-y-4"><div className="flex justify-between"><h3 className="font-bold">쿠폰 · 상품권 등록</h3><button aria-label="닫기" onClick={onClose}><X size={20}/></button></div><p className="text-xs text-slate-500">체험 카드 잔액 {currentBalance.toLocaleString()}원</p><input aria-label="등록 코드" className="border rounded-xl w-full p-3 text-sm" placeholder="코드를 입력해주세요" value={code} maxLength={40} onChange={e=>setCode(e.target.value)}/>{error&&<p className="text-xs text-red-600" role="alert">{error}</p>}<button disabled={busy||!code.trim()} className="w-full bg-sky-500 text-white p-3 rounded-xl font-bold disabled:opacity-50" onClick={async()=>{setBusy(true);try{await onTopUp(code)}catch(e){setError(e.message)}finally{setBusy(false)}}}>{busy?'등록 중…':'등록하기'}</button><p className="text-xs bg-sky-50 p-3 rounded-xl leading-6">WELCOME1000 · 1,000원 할인 쿠폰<br/>테스트 잔액은 관리자 계정에서 충전<br/>각 코드 1회 사용 · 실제 상품권 사용 불가</p></div></div>}

function BarcodeModal({ data, onClose }) {
  return (
    <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
      <div className="bg-white w-full max-w-xs rounded-3xl p-5 text-center space-y-4 shadow-2xl animate-in zoom-in-95">
        <div className="flex justify-between items-center">
          <span className="text-xs font-extrabold text-slate-700">{data.title}</span>
          <button onClick={onClose}><X className="w-5 h-5 text-slate-400" /></button>
        </div>

        <div className="bg-slate-100 p-4 rounded-2xl space-y-2 border border-slate-200">
          <div className="h-16 bg-slate-900 w-full rounded flex justify-around items-center px-2">
            {Array.from({ length: 28 }).map((_, i) => (
              <div 
                key={i} 
                className={`h-full bg-white ${i % 3 === 0 ? 'w-1.5' : 'w-0.5'}`}
              ></div>
            ))}
          </div>
          <div className="text-xs font-mono font-bold tracking-widest text-slate-800">
            {data.code}
          </div>
        </div>

        <p className="text-[10px] text-slate-400">화면 확인용 예시 바코드입니다. 실제 결제·스캔은 지원하지 않습니다.</p>
      </div>
    </div>
  );
}





function ProductVisual({item}){
  const photos={m1:'latte',m2:'americano',m3:'blue',m4:'americano',m5:'latte',m10:'croissant'};
  const drinks={m6:0,m7:1,m11:2,m13:3,m14:4,m15:5,m16:6,m17:7,m12:8};
  const desserts={m8:0,m19:1,m20:2,m21:3,m22:4,m23:5,m24:6,m25:7,m26:8};
  const photo=photos[item.id];
  const sprite=Object.hasOwn(drinks,item.id)?['drink',drinks[item.id]]:Object.hasOwn(desserts,item.id)?['dessert',desserts[item.id]]:null;
  const className=photo?'edy-product-photo '+photo:sprite?'edy-product-photo '+sprite[0]:item.id==='m18'?'edy-product-photo tea':null;
  const style=sprite?{backgroundPosition:`${(sprite[1]%3)*50}% ${Math.floor(sprite[1]/3)*50}%`}:undefined;
  return className?<span className={className} style={style} role="img" aria-label={item.name+' 연출 이미지'}/>:<span>{item.image}</span>;
}
