import React,{createContext,useContext,useEffect,useState} from 'react';
import {newMember,clean,createOrder,finish,publicMember,orderStage} from '../lib/domain';
import {authenticate,getAccount,clearSession,creditAccount,debitAccount,allocatePickupNumber} from '../lib/account-client';
const Context=createContext(null);let queue=Promise.resolve();
async function transaction(fn){
 const account=await getAccount(), key='eodiya-member-v2-'+(account?.id||'guest');
 const run=async()=>{let member;try{member=JSON.parse(localStorage.getItem(key)||'null')}catch{}if(!member){member=newMember(crypto.randomUUID());member.balance=0}if(account)member.balance=Number(account.balance);const result=await fn(member,account);localStorage.setItem(key,JSON.stringify(member));return result};
 if(navigator.locks)return navigator.locks.request(key,run);
 const p=queue.then(run,run);queue=p.catch(()=>{});return p;
}
export async function api(url,data){return transaction(async(m,account)=>{
 clean(m);
 if(url==='/api/member')return{member:publicMember(m),account,config:{mode:'demo',clientKey:'',applePay:false}};
 if(url==='/api/orders'){
  if(data.paymentMethod==='APPLEPAY')throw new Error('Apple Pay는 정적 테스트에서 지원하지 않습니다.');
  if(!account)throw new Error('주문 전 로그인해주세요.');
  const order=createOrder(m,data);
  if(order.amount>Number(account.balance))throw new Error('잔액이 부족하여 주문할 수 없습니다. 관리자에게 충전을 요청해주세요.');
  return{order};
 }
 if(url==='/api/payment/complete'){
  const o=m.orders.find(o=>o.id===data.orderId);if(!o||o.amount!==data.amount)throw new Error('주문 금액을 확인해주세요.');
  if(!account)throw new Error('주문 전 로그인해주세요.');
  if(o.paymentMethod!=='WALLET'&&o.status!=='paid'&&o.amount>Number(account.balance))throw new Error('잔액이 부족하여 주문할 수 없습니다. 관리자에게 충전을 요청해주세요.');
  if(o.paymentMethod==='WALLET'&&o.status!=='paid'){
   const draft=structuredClone(m);draft.balance=Math.max(draft.balance,o.amount);const order=finish(draft,o.id,'browser_demo_'+o.id);
   const result=await debitAccount(o.id,o.amount);order.number=await allocatePickupNumber(o.id);draft.balance=Number(result.balance);Object.assign(m,draft);return{order};
  }
  if(o.status!=='paid')o.number=await allocatePickupNumber(o.id);
  return{order:finish(m,o.id,'browser_demo_'+o.id)};
 }
 if(url==='/api/redeem'){
  const code=String(data.code||'').trim().toUpperCase();if(code==='GIFT10000')throw new Error('테스트 잔액은 관리자 계정에서 충전해주세요.');
  if(code!=='WELCOME1000')throw new Error('등록할 수 없는 코드입니다.');if(m.redemptions.includes(code))throw new Error('이미 등록한 코드입니다.');
  m.redemptions.push(code);m.coupons.push({id:crypto.randomUUID(),name:'웰컴 1,000원 할인',kind:'discount',amount:1000,expires:Date.now()+30*86400000,used:false});return{message:'할인 쿠폰이 등록되었어요.'};
 }
 if(url.startsWith('/api/orders/')){const id=url.split('/')[3],o=m.orders.find(o=>o.id===id);if(!o)throw new Error('주문을 찾을 수 없습니다.');if(data?.action==='pickup'){if(orderStage(o)!=='ready')throw new Error('아직 준비 중인 주문입니다.');o.pickedAt=Date.now()}if(data?.action==='cancel'){if(o.status!=='pending')throw new Error('완료된 주문은 취소할 수 없습니다.');o.status='cancelled';const c=m.coupons.find(c=>c.reserved===id);if(c)c.reserved=undefined}return{order:{...o,stage:orderStage(o)}}}
 throw new Error('지원하지 않는 테스트 기능입니다.');
})}
export function MemberProvider({children}){
 const[cart,setCartState]=useState([]),[member,setMember]=useState(null),[account,setAccount]=useState(null),[sessionReady,setSessionReady]=useState(false),[error,setError]=useState(''),[mode,setMode]=useState('pickup');
 async function refresh(){try{const r=await api('/api/member');setMember(r.member);setAccount(r.account);setError('')}catch(e){setError(e.message);setAccount(null)}}
 async function login(id,password){await authenticate('login',id,password);setCart([]);await refresh()}
 async function register(id,password){await authenticate('signup',id,password);setCart([]);await refresh()}
 async function logout(){clearSession();setCart([]);await refresh()}
 async function credit(id,amount){await getAccount();await creditAccount(id,amount);await refresh()}
 useEffect(()=>{try{setCartState(JSON.parse(localStorage.getItem('eodiya-edy-cart')||'[]'))}catch{}void refresh().finally(()=>setSessionReady(true));const listener=()=>void refresh();window.addEventListener('storage',listener);if('serviceWorker'in navigator)navigator.serviceWorker.register('/EDY/menu/sw.js',{scope:'/EDY/menu/'}).catch(()=>{});return()=>window.removeEventListener('storage',listener)},[]);
 function setCart(v){setCartState(v);localStorage.setItem('eodiya-edy-cart',JSON.stringify(v))}
 return <Context.Provider value={{cart,setCart,member,account,sessionReady,login,register,logout,credit,refresh,error,config:{mode:'demo',clientKey:'',applePay:false},mode,setMode}}>{children}</Context.Provider>;
}
export const useMember=()=>useContext(Context);
