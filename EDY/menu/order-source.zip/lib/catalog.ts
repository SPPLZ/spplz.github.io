export type Options={temperature:'ICE'|'HOT';cup:'일회용컵'|'개인컵'|'매장컵';size:'R'|'EX';shots:number;syrup:'기본'|'적게'|'없이'|'추가';ice:'보통'|'적게'|'없이'|'많이';syrupShots:number};
export type CartItem={id:string;productId:string;quantity:number;options:Options};
export const defaults:Options={temperature:'ICE',cup:'일회용컵',size:'R',shots:0,syrup:'기본',ice:'보통',syrupShots:0};
export const products=[
  {
    "id": "m1",
    "name": "시그니처 바닐라 라떼",
    "en": "Signature Vanilla Latte",
    "price": 3800,
    "category": "추천메뉴",
    "tone": "latte",
    "tag": "BEST",
    "description": "부드러운 우유와 바닐라 향, 깊은 에스프레소의 만남",
    "drink": true,
    "iced": false,
    "image": "☕",
    "popular": true
  },
  {
    "id": "m2",
    "name": "시험기간 열공 아메리카노 (EX)",
    "en": "Hard Study Extra Americano",
    "price": 2800,
    "category": "추천메뉴",
    "tone": "coffee",
    "tag": "대용량",
    "description": "대림대 학생들을 위한 고함량 카페인 빅사이즈 4샷 아메리카노",
    "drink": true,
    "iced": false,
    "image": "☕",
    "popular": true
  },
  {
    "id": "m3",
    "name": "블루 스카이 플랫치노",
    "en": "Eodiya Blue Sky Flatccino",
    "price": 4300,
    "category": "플랫치노/스무디",
    "tone": "sky",
    "tag": "SIGNATURE",
    "description": "어디야커피의 하늘색 감성을 담은 청량하고 달콤한 소다 플랫치노",
    "drink": true,
    "iced": true,
    "image": "🧊",
    "popular": true
  },
  {
    "id": "m4",
    "name": "딥 에스프레소 아메리카노",
    "en": "Deep Espresso Americano",
    "price": 2500,
    "category": "커피",
    "tone": "coffee",
    "tag": "",
    "description": "스페셜티 원두로 고소함과 풍부한 바디감을 느낄 수 있는 기본 아메리카노",
    "drink": true,
    "iced": false,
    "image": "☕",
    "popular": true
  },
  {
    "id": "m5",
    "name": "수제 바닐라 빈 라떼",
    "en": "Real Vanilla Bean Latte",
    "price": 3800,
    "category": "커피",
    "tone": "latte",
    "tag": "",
    "description": "천연 바닐라 빈 시럽을 넣어 진하고 은은한 단맛이 매력적인 바닐라 라떼",
    "drink": true,
    "iced": false,
    "image": "🥛",
    "popular": true
  },
  {
    "id": "m6",
    "name": "리얼 딸기 연유 라떼",
    "en": "Real Strawberry Condensed Milk Latte",
    "price": 4200,
    "category": "라떼/베버리지",
    "tone": "berry",
    "tag": "",
    "description": "상큼한 딸기 과육과 달콤한 연유가 가득 들어간 부드러운 우유 라떼",
    "drink": true,
    "iced": true,
    "image": "🍓",
    "popular": true
  },
  {
    "id": "m7",
    "name": "자몽 블랙 티 (Jong-Black Tea)",
    "en": "Grapefruit Black Tea",
    "price": 3800,
    "category": "블렌딩티/에이드",
    "tone": "latte",
    "tag": "",
    "description": "달콤 쌉싸름한 자몽 청과 깊은 풍미의 잉글리시 브렉퍼스트 홍차의 만남",
    "drink": true,
    "iced": false,
    "image": "🍹",
    "popular": false
  },
  {
    "id": "m8",
    "name": "어디야 수제 크로플 & 아이스크림",
    "en": "Eodiya Croffle & Ice Cream",
    "price": 4500,
    "category": "디저트/베이커리",
    "tone": "bread",
    "tag": "HOT DESSERT",
    "description": "갓 구운 겉바속촉 크로플 위에 바닐라 아이스크림과 메이플 시럽",
    "drink": false,
    "iced": true,
    "image": "🥐",
    "popular": true
  },
  {
    "id": "m9",
    "name": "어디야 데일리 텀블러",
    "en": "Eodiya Daily Tumbler",
    "price": 18000,
    "category": "MD",
    "tone": "tumbler",
    "tag": "MD",
    "description": "캠퍼스의 하루를 담는 500ml 텀블러",
    "drink": false,
    "iced": false,
    "image": "🥤",
    "popular": false
  }
,{id:"m10",name:"버터 크루아상",en:"Butter Croissant",price:3200,category:"디저트/베이커리",tone:"bread",tag:"PAIRING",description:"겹겹이 바삭한 결에 고소한 버터 향을 담은 커피의 다정한 짝꿍",drink:false,iced:true,image:"🥐",popular:true}
];
export const stores=[{id:'campus',name:'대림대학교점',address:'경기 안양시 동안구 임곡로 29 · 과제용 매장',hours:'08:00–21:00',distance:'캠퍼스 안',time:'5–10분'}];
export function unitPrice(item:CartItem){const p=products.find(p=>p.id===item.productId);if(!p)throw new Error('메뉴를 찾을 수 없습니다.');if(!p.drink)return p.price;const o=item.options;return p.price+(o.size==='EX'?1200:0)+o.shots*500+o.syrupShots*500-(o.cup==='개인컵'?300:0)}
export const money=(n:number)=>n.toLocaleString('ko-KR')+'원';
export function describe(item:CartItem){const p=products.find(p=>p.id===item.productId);if(!p?.drink)return p?.category||'';const o=item.options;return `${o.temperature} · ${o.size} · ${o.cup}${o.shots?' · 샷 +'+o.shots:''} · 시럽 ${o.syrup}${o.temperature==='ICE'?' · 얼음 '+o.ice:''}`}
