import React from 'react';import {createRoot} from 'react-dom/client';import App from './components/reference-app';import {MemberProvider} from './components/member-provider';import './style.css';
createRoot(document.getElementById('root')).render(<MemberProvider><App/></MemberProvider>);
